const API = "http://127.0.0.1:5000/api";

export default API;